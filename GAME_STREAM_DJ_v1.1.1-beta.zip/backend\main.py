"""
GAME STREAM DJ - Python Backend
Features:
- WebSocket server for realtime UI communication
- Clipboard monitoring (auto-detect YouTube URLs)
- Global hotkey support
- OBS WebSocket integration
- Audio analysis for loop detection (using yt-dlp + librosa)
- State persistence (JSON)
"""

import os
import sys
import json
import asyncio
import logging
import threading
import time
import re
from pathlib import Path
from typing import Dict, List, Optional, Set
from contextlib import asynccontextmanager

# FastAPI
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

# Optional imports - gracefully handle if not installed
try:
    import pyperclip
    CLIPBOARD_AVAILABLE = True
except ImportError:
    CLIPBOARD_AVAILABLE = False
    print("[WARN] pyperclip not installed. Clipboard monitoring disabled.")

try:
    import keyboard
    KEYBOARD_AVAILABLE = True
except ImportError:
    KEYBOARD_AVAILABLE = False
    print("[WARN] keyboard not installed. Hotkeys disabled.")

try:
    import obsws_python as obs
    OBS_AVAILABLE = True
except ImportError:
    OBS_AVAILABLE = False
    print("[WARN] obsws-python not installed. OBS integration disabled.")

try:
    import yt_dlp
    import numpy as np
    import librosa
    AUDIO_ANALYSIS_AVAILABLE = True
except ImportError:
    AUDIO_ANALYSIS_AVAILABLE = False
    print("[WARN] yt-dlp/librosa/numpy not installed. Audio analysis disabled.")

# Setup Logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s'
)
logger = logging.getLogger("GameStreamDJ")

# ============ Constants ============
BASE_DIR = Path(__file__).parent
STATE_FILE = BASE_DIR / "dj_state.json"
TEMP_AUDIO_DIR = BASE_DIR / "temp_audio"
TEMP_AUDIO_DIR.mkdir(exist_ok=True)

DEFAULT_STATE = {
    "playlists": {
        "deckA": [],
        "deckB": [],
        "library": []
    },
    "settings": {
        "hotkeySwitch": "F8",
        "obsHost": "localhost",
        "obsPort": 4455,
        "obsPassword": ""
    }
}

# ============ Application State ============
class AppState:
    def __init__(self):
        self.playlists = DEFAULT_STATE["playlists"].copy()
        if "library" not in self.playlists:
            self.playlists["library"] = []
            
        self.settings = DEFAULT_STATE["settings"].copy()
        self.websockets: Set[WebSocket] = set()
        self.clipboard_watch_enabled = False
        self.last_clipboard = ""
        self.obs_client = None
        self.hotkey_registered = False
        self.load_state()

    def load_state(self):
        if STATE_FILE.exists():
            try:
                with open(STATE_FILE, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.playlists = data.get("playlists", DEFAULT_STATE["playlists"])
                    # Migrate old state
                    if "library" not in self.playlists:
                        self.playlists["library"] = []
                        
                    self.settings = data.get("settings", DEFAULT_STATE["settings"])
                logger.info("State loaded from file")
            except Exception as e:
                logger.error(f"Failed to load state: {e}")

    def save_state(self):
        try:
            with open(STATE_FILE, 'w', encoding='utf-8') as f:
                json.dump({
                    "playlists": self.playlists,
                    "settings": self.settings
                }, f, indent=2, ensure_ascii=False)
            logger.info("State saved")
        except Exception as e:
            logger.error(f"Failed to save state: {e}")

    async def broadcast(self, message: dict):
        """Send message to all connected WebSocket clients"""
        dead = set()
        for ws in self.websockets:
            try:
                await ws.send_json(message)
            except:
                dead.add(ws)
        self.websockets -= dead

app_state = AppState()
event_loop = None

# ============ Background Services ============

async def clipboard_monitor():
    """Monitor clipboard for YouTube URLs"""
    global app_state
    logger.info("Clipboard monitor started")
    
    youtube_pattern = re.compile(r'(https?://)?(www\.)?(youtube\.com/watch\?v=|youtu\.be/)[\w-]+')
    
    while True:
        await asyncio.sleep(1.0)
        
        if not app_state.clipboard_watch_enabled or not CLIPBOARD_AVAILABLE:
            continue
            
        try:
            text = pyperclip.paste()
            if text and text != app_state.last_clipboard:
                app_state.last_clipboard = text
                if youtube_pattern.search(text):
                    logger.info(f"Clipboard detected YouTube URL: {text}")
                    await app_state.broadcast({
                        "type": "clipboard_url",
                        "url": text
                    })
        except Exception as e:
            logger.debug(f"Clipboard error: {e}")

def register_hotkeys():
    """Register global hotkeys"""
    if not KEYBOARD_AVAILABLE:
        return
    
    def on_hotkey():
        if event_loop:
            asyncio.run_coroutine_threadsafe(
                app_state.broadcast({"type": "hotkey_triggered", "action": "switch"}),
                event_loop
            )
    
    try:
        hotkey = app_state.settings.get("hotkeySwitch", "F1").lower()
        keyboard.on_press_key(hotkey, lambda e: on_hotkey())
        app_state.hotkey_registered = True
        logger.info(f"Hotkey '{hotkey}' registered")
    except Exception as e:
        logger.error(f"Failed to register hotkey: {e}")

def connect_obs():
    """Connect to OBS WebSocket"""
    if not OBS_AVAILABLE:
        return False
    
    try:
        host = app_state.settings.get("obsHost", "localhost")
        port = app_state.settings.get("obsPort", 4455)
        password = app_state.settings.get("obsPassword", "")
        
        app_state.obs_client = obs.ReqClient(host=host, port=port, password=password)
        logger.info("Connected to OBS")
        
        # Start scene monitoring in background
        threading.Thread(target=obs_scene_monitor, daemon=True).start()
        return True
    except Exception as e:
        logger.error(f"OBS connection failed: {e}")
        return False

def obs_scene_monitor():
    """Monitor OBS scene changes"""
    if not app_state.obs_client:
        return
    
    last_scene = ""
    while True:
        try:
            response = app_state.obs_client.get_current_program_scene()
            current_scene = response.current_program_scene_name
            
            if current_scene != last_scene:
                last_scene = current_scene
                if event_loop:
                    asyncio.run_coroutine_threadsafe(
                        app_state.broadcast({
                            "type": "obs_scene_changed",
                            "scene": current_scene
                        }),
                        event_loop
                    )
        except Exception as e:
            logger.debug(f"OBS monitor error: {e}")
        
        time.sleep(0.5)

# ============ Audio Analysis ============

def find_zero_crossings(audio: np.ndarray) -> np.ndarray:
    """Find indices where audio signal crosses zero"""
    return np.where(np.diff(np.signbit(audio)))[0]

def analyze_loop_points(url: str) -> dict:
    """
    Analyze audio to find optimal loop points using Cross-Correlation with Phase Matching.
    """
    if not AUDIO_ANALYSIS_AVAILABLE:
        return {"success": False, "error": "Audio analysis libraries not installed"}
    
    try:
        # Download audio
        ydl_opts = {
            'format': 'bestaudio/best',
            'outtmpl': str(TEMP_AUDIO_DIR / 'temp_%(id)s.%(ext)s'),
            'postprocessors': [{
                'key': 'FFmpegExtractAudio',
                'preferredcodec': 'wav',
                'preferredquality': '192',
            }],
            'quiet': True,
            'extract_flat': False,
            # Enable Node.js runtime for YouTube signature decryption
            'js_runtimes': {'node': {'path': r'C:\Program Files\nodejs\node.exe'}},
            # Enable remote EJS components from GitHub for challenge solving
            'remote_components': ['ejs:github'],
        }
        
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            # Handle if user passed a playlist URL by mistake - take first item
            info = ydl.extract_info(url, download=True)
            if 'entries' in info:
                info = info['entries'][0]
            
            video_id = info['id']
            audio_path = TEMP_AUDIO_DIR / f'temp_{video_id}.wav'
        
        # Cleanup routine
        def cleanup():
            try:
                if audio_path.exists(): audio_path.unlink()
            except: pass

        if not audio_path.exists():
            for f in TEMP_AUDIO_DIR.glob(f'temp_{video_id}.*'):
                audio_path = f
                break
        
        # Load audio (mono for correlation)
        logger.info("Loading audio for analysis...")
        y, sr = librosa.load(str(audio_path), sr=22050, mono=True)
        duration = len(y) / sr
        
        # --- Cross-Correlation Strategy V2 (Phase Matching) ---
        from scipy import signal
        
        # 1. Select Reference Segment (Query)
        # Use segment from end, but ensure it starts/ends on zero crossings
        # to ensure the reference itself is "clean"
        raw_test_end_time = duration - 5
        query_duration = 15.0 if duration > 60 else duration / 4
        raw_test_start_time = raw_test_end_time - query_duration
        
        # Adjust query window to nearest zero crossings
        zcs = np.where(np.diff(np.signbit(y)))[0]
        
        start_idx = int(raw_test_start_time * sr)
        end_idx = int(raw_test_end_time * sr)
        
        # Snap start/end to nearest ZC
        if len(zcs) > 0:
            start_idx = zcs[np.abs(zcs - start_idx).argmin()]
            end_idx = zcs[np.abs(zcs - end_idx).argmin()]
        
        query_segment = y[start_idx:end_idx]
        test_start_time = start_idx / sr # Exact start time of query
        
        # 2. Search Area
        search_end_idx = start_idx - int(5 * sr) # Don't overlap
        search_wave = y[:search_end_idx]
        
        logger.info("Running cross-correlation...")
        # FFT based correlation is fast
        correlation = signal.correlate(search_wave, query_segment, mode='valid', method='fft')
        
        # Find peaks
        peak_idx = np.argmax(correlation)
        peak_score = correlation[peak_idx]
        
        # Normalize score
        energy_query = np.sum(query_segment**2)
        energy_match = np.sum(search_wave[peak_idx:peak_idx+len(query_segment)]**2)
        norm_score = peak_score / np.sqrt(energy_query * energy_match)
        
        loop_start_sec = peak_idx / sr
        loop_end_sec = test_start_time
        
        # 3. Phase Match Checking (Slope)
        if peak_idx + 1 < len(y) and peak_idx < len(y) and start_idx + 1 < len(y):
            slope_start = np.sign(y[peak_idx+1] - y[peak_idx])
            slope_end = np.sign(y[start_idx+1] - y[start_idx])
            
            # If slopes opposite, move to next zero crossing
            if slope_start != slope_end:
                logger.info("Slope mismatch, adjusting to next zero crossing...")
                # Find next ZC near loop_start_sec
                local_zcs = zcs[(zcs > peak_idx) & (zcs < peak_idx + 1000)]
                if len(local_zcs) > 0:
                    peak_idx = local_zcs[0]
                    loop_start_sec = peak_idx / sr
        
        cleanup()
        logger.info(f"Loop Found: {loop_start_sec:.3f}s -> {loop_end_sec:.3f}s (Conf: {norm_score:.3f})")
        
        return {
            "success": True,
            "loopStart": round(loop_start_sec, 3),
            "loopEnd": round(loop_end_sec, 3),
            "duration": round(duration, 1),
            "confidence": round(float(norm_score), 2)
        }
        
    except Exception as e:
        logger.error(f"Loop analysis failed: {e}")
        return {"success": False, "error": str(e)}

# ============ FastAPI App ============

@asynccontextmanager
async def lifespan(app: FastAPI):
    global event_loop
    event_loop = asyncio.get_running_loop()
    
    # Start background tasks
    asyncio.create_task(clipboard_monitor())
    
    # Register hotkeys
    if KEYBOARD_AVAILABLE:
        threading.Thread(target=register_hotkeys, daemon=True).start()
    
    logger.info("GAME STREAM DJ Backend started")
    yield
    
    # Cleanup
    if KEYBOARD_AVAILABLE:
        try:
            keyboard.unhook_all()
        except:
            pass
    logger.info("Backend shutdown")

app = FastAPI(lifespan=lifespan, title="GAME STREAM DJ Backend")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ============ Extra API ============

@app.post("/api/import_playlist")
async def import_playlist(data: dict):
    url = data.get("url")
    if not url:
        return {"success": False, "error": "No URL provided"}
        
    try:
        ydl_opts = {
            'extract_flat': True, # Fast extraction, don't download
            'quiet': True
        }
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            
            if 'entries' not in info:
                return {"success": False, "error": "Not a playlist"}
                
            tracks = []
            for entry in info['entries']:
                if entry.get('title') != '[Private video]' and entry.get('title') != '[Deleted video]':
                    tracks.append({
                        "url": f"https://www.youtube.com/watch?v={entry['id']}",
                        "title": entry.get('title', 'Unknown Track')
                    })
                    
            return {"success": True, "tracks": tracks}
            
    except Exception as e:
        logger.error(f"Playlist import failed: {e}")
        return {"success": False, "error": str(e)}

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    app_state.websockets.add(websocket)
    logger.info(f"WebSocket connected. Total: {len(app_state.websockets)}")
    
    # Send current state
    await websocket.send_json({
        "type": "state",
        "playlists": app_state.playlists,
        "settings": app_state.settings
    })
    
    try:
        while True:
            data = await websocket.receive_json()
            await handle_ws_message(websocket, data)
    except WebSocketDisconnect:
        app_state.websockets.discard(websocket)
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
        app_state.websockets.discard(websocket)

async def handle_ws_message(ws: WebSocket, data: dict):
    msg_type = data.get("type", "")
    
    if msg_type == "get_state":
        await ws.send_json({
            "type": "state",
            "playlists": app_state.playlists,
            "settings": app_state.settings
        })
    
    elif msg_type == "save_state":
        if "playlists" in data:
            app_state.playlists = data["playlists"]
        
        # Check if settings changed, especially hotkey
        hotkey_changed = False
        if "settings" in data:
            new_hotkey = data["settings"].get("hotkeySwitch")
            if new_hotkey and new_hotkey != app_state.settings.get("hotkeySwitch"):
                hotkey_changed = True
            app_state.settings.update(data["settings"])
            
        app_state.save_state()
        
        # Re-register hotkeys if changed
        if hotkey_changed and KEYBOARD_AVAILABLE:
            try:
                keyboard.unhook_all()
                threading.Thread(target=register_hotkeys, daemon=True).start()
                logger.info("Hotkeys re-registered")
            except Exception as e:
                logger.error(f"Failed to re-register hotkeys: {e}")
                
        await ws.send_json({"type": "state_saved", "success": True})
    
    elif msg_type == "clipboard_watch":
        app_state.clipboard_watch_enabled = data.get("enabled", False)
    
    elif msg_type == "obs_connect":
        success = connect_obs()
        await ws.send_json({"type": "obs_connected", "success": success})
    
    elif msg_type == "obs_switch":
        scene = data.get("scene")
        if app_state.obs_client and scene:
            try:
                app_state.obs_client.set_current_program_scene(scene)
                logger.info(f"OBS Switched to scene: {scene}")
            except Exception as e:
                logger.error(f"Failed to switch OBS scene: {e}")
    
    elif msg_type == "analyze_loop":
        url = data.get("url", "")
        if url:
            loop = asyncio.get_running_loop()
            result = await loop.run_in_executor(None, analyze_loop_points, url)
            await ws.send_json({"type": "loop_analyzed", **result})
            
    elif msg_type == "obs_update_config":
        # Update OBS connection settings from frontend
        if "host" in data:
            app_state.settings["obsHost"] = data["host"]
        if "port" in data:
            app_state.settings["obsPort"] = data["port"]
        if "password" in data:
            app_state.settings["obsPassword"] = data["password"]
        app_state.save_state()
        logger.info("OBS config updated from frontend")

    elif msg_type == "import_playlist":
        url = data.get("url", "")
        if url:
            # We call the functionality directly here for simplicity over ws
            # But normally we'd keep logic separate. 
            # Re-using the logic from the API endpoint would be cleaner but for now:
            # We'll just trigger the same logic if needed or let frontend call the API.
            # Frontend handles this via REST usually, but let's confirm.
            pass

# Serve static files (frontend)
frontend_dir = BASE_DIR.parent / "frontend"
if frontend_dir.exists():
    app.mount("/", StaticFiles(directory=str(frontend_dir), html=True), name="static")
else:
    # Try alternate path
    alt_frontend = BASE_DIR / ".." / "frontend"
    if alt_frontend.exists():
        app.mount("/", StaticFiles(directory=str(alt_frontend.resolve()), html=True), name="static")

# ============ Main ============

if __name__ == "__main__":
    print("=" * 50)
    print("  GAME STREAM DJ - Backend Server")
    print("=" * 50)
    print(f"  Clipboard Monitor: {'OK' if CLIPBOARD_AVAILABLE else 'NG'}")
    print(f"  Global Hotkeys:    {'OK' if KEYBOARD_AVAILABLE else 'NG'}")
    print(f"  OBS Integration:   {'OK' if OBS_AVAILABLE else 'NG'}")
    print(f"  Audio Analysis:    {'OK' if AUDIO_ANALYSIS_AVAILABLE else 'NG'}")
    print("=" * 50)
    print("  Starting server at http://127.0.0.1:8000")
    print("=" * 50)
    
    uvicorn.run(app, host="127.0.0.1", port=8000, log_level="info")
