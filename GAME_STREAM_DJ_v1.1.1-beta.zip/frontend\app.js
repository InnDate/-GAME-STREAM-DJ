/**
 * 自作GAME STREAM DJ - v1.1.1-beta
 * Per-direction triggers, thumbnails, bug fixes
 */

// ============ STATE ============
const state = {
    mode: 'A',

    // Timer
    timerDuration: 600000,
    timerStartTime: 0,
    timerInterval: null,

    deckA: {
        videoId: '', currentUrl: '', player: null, ready: false, volume: 80,
        queue: [],
        duration: 0
    },

    deckB: {
        videoId: '', currentUrl: '', p1: null, p2: null, activePlayer: 1,
        ready1: false, ready2: false,
        volume: 80, loopStart: 6, loopEnd: 92,
        queue: [],
        nextLoopQueued: false,
        switching: false
    },

    library: [], // All saved tracks

    crossfade: 0,
    ws: null, wsConnected: false,
    clipboardWatchEnabled: false,
    pendingHotkeySwitch: false,

    settings: {
        hotkeySwitch: 'F8',
        testLoopDuration: 1.5,
        switchModeAB: 'resume',
        switchModeBA: 'resume',
        timerMinutesAB: 10,
        timerMinutesBA: 10,
        timerEnabledAB: false,
        timerEnabledBA: false,
        fadeDurationAB: 2.0,
        fadeDurationBA: 2.0,
        obsEnabledAB: false,
        obsEnabledBA: false,
        obsHost: 'localhost',
        obsPort: 4455,
        obsPassword: '',
        obsSceneA: 'Deck A',
        obsSceneB: 'Deck B',
        clipboardTargetDeck: 'library',
        clipboardWatchEnabled: false,
        playModeA: 'order',
        playModeB: 'order'
    },

    isTestingLoop: false,
    history: [],

    // D&D Scroll State
    dnd: {
        activeContainer: null,
        lastY: null,
        interval: null
    }
};
const MAX_HISTORY = 30;

function pushHistory() {
    if (state.history.length >= MAX_HISTORY) state.history.shift();
    state.history.push(JSON.stringify({
        playlists: {
            deckA: state.deckA.queue,
            deckB: state.deckB.queue,
            library: state.library
        }
    }));
}

function undo() {
    if (state.history.length === 0) {
        showToast("Nothing to Undo");
        return;
    }
    const prevStr = state.history.pop();
    const prev = JSON.parse(prevStr);

    state.deckA.queue = prev.playlists.deckA;
    state.deckB.queue = prev.playlists.deckB;
    state.library = prev.playlists.library;

    renderAllLists();
    saveState(false);
    showToast("Undo Successful");
}

// ============ ENGINE (Loop & UI Update) ============

setInterval(() => {
    // Deck A
    if (state.deckA.player && state.deckA.ready && state.deckA.player.getCurrentTime) {
        updateDeckUI('deckA', state.deckA.player.getCurrentTime(), state.deckA.player.getDuration());
    }
    // Deck B
    updateDeckBLoopLogic();
}, 50);

function updateDeckUI(deckKey, time, duration) {
    const tEl = document.getElementById(deckKey === 'deckA' ? 'info-a-time' : 'info-b-time');
    if (tEl) tEl.textContent = `${formatTime(time)} / ${formatTime(duration)}`;

    const seekEl = document.getElementById(deckKey === 'deckA' ? 'seek-a' : 'seek-b');
    if (document.activeElement !== seekEl && duration > 0) {
        seekEl.value = (time / duration) * 100;
        seekEl.style.backgroundSize = `${(time / duration) * 100}% 100%`;
    }
}

function updateDeckBLoopLogic() {
    if (!state.deckB.ready1 || !state.deckB.ready2 || state.deckB.switching) return;

    const activeP = state.deckB.activePlayer === 1 ? state.deckB.p1 : state.deckB.p2;
    const nextP = state.deckB.activePlayer === 1 ? state.deckB.p2 : state.deckB.p1;

    if (!activeP || !activeP.getCurrentTime) return;
    if (activeP.getPlayerState() !== YT.PlayerState.PLAYING && !state.isTestingLoop) return;

    const currTime = activeP.getCurrentTime();
    updateDeckUI('deckB', currTime, activeP.getDuration());

    const remaining = state.deckB.loopEnd - currTime;

    // Preload (3s before)
    if (remaining < 3 && !state.deckB.nextLoopQueued) {
        nextP.seekTo(state.deckB.loopStart);
        nextP.pauseVideo();
        state.deckB.nextLoopQueued = true;
    }

    // Switch (0.1s before)
    if (remaining <= 0.1 && state.deckB.nextLoopQueued) {
        const vol = state.isTestingLoop ? 100 : (state.deckB.volume * (state.crossfade / 100));
        nextP.setVolume(vol);
        nextP.playVideo();

        state.deckB.switching = true;
        setTimeout(() => {
            activeP.pauseVideo();
            state.deckB.switching = false;
        }, 150);

        state.deckB.activePlayer = state.deckB.activePlayer === 1 ? 2 : 1;
        state.deckB.nextLoopQueued = false;
    }
}

// ============ UTILS ============

function formatTime(s) {
    if (!s || isNaN(s)) return "0:00";
    const m = Math.floor(s / 60);
    const sec = Math.floor(s % 60);
    return `${m}:${sec.toString().padStart(2, '0')}`;
}

function resetDeckB() {
    state.deckB.activePlayer = 1;
    state.deckB.nextLoopQueued = false;
    state.deckB.switching = false;
    if (state.deckB.p1) state.deckB.p1.pauseVideo();
    if (state.deckB.p2) state.deckB.p2.pauseVideo();
}

// ============ UI EVENTS ============

document.addEventListener('DOMContentLoaded', () => {
    connectWebSocket();
    setupEventListeners();
    setupGlobalKeyboardShortcuts();

    const tag = document.createElement('script');
    tag.src = "https://www.youtube.com/iframe_api";
    document.head.appendChild(tag);
});

function setupGlobalKeyboardShortcuts() {
    document.addEventListener('keydown', (e) => {
        // Ignore if typing in an input field
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.isContentEditable) {
            return;
        }

        if (e.code === 'Space') {
            e.preventDefault();
            // Toggle play/pause on active deck
            togglePlay(state.mode === 'A' ? 'deckA' : 'deckB');
        }

        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
            e.preventDefault();
            undo();
        }
    });
}

function setupEventListeners() {
    // Play/Pause
    document.getElementById('btn-play-a').onclick = () => togglePlay('deckA');
    document.getElementById('btn-play-b').onclick = () => togglePlay('deckB');

    // Load
    document.getElementById('btn-load-a').onclick = () => loadTrackDirect('deckA', document.getElementById('input-a').value);
    document.getElementById('btn-load-b').onclick = () => loadTrackDirect('deckB', document.getElementById('input-b').value);

    // Add to Library (from Deck)
    document.getElementById('btn-add-a').onclick = () => addToLibraryFromDeck('deckA');
    document.getElementById('btn-add-b').onclick = () => addToLibraryFromDeck('deckB');

    // Clipboard Settings (Main UI)
    const clipWatch = document.getElementById('clipboard-watch');
    if (clipWatch) {
        clipWatch.onchange = (e) => {
            state.clipboardWatchEnabled = e.target.checked;
            state.settings.clipboardWatchEnabled = e.target.checked; // Persistence
            saveState(false);
            if (state.ws) state.ws.send(JSON.stringify({ type: 'clipboard_watch', enabled: e.target.checked }));
        };
    }
    const clipTarget = document.getElementById('clipboard-target');
    if (clipTarget) {
        clipTarget.onchange = (e) => {
            state.settings.clipboardTargetDeck = e.target.value;
            saveState(false);
            showToast(`Target: ${e.target.value}`);
        };
    }

    // Modal Settings
    const modal = document.getElementById('settings-modal');
    const openBtn = document.getElementById('btn-open-settings');
    const closeBtn = document.getElementById('btn-close-settings');

    if (openBtn) {
        openBtn.onclick = () => {
            modal.classList.remove('hidden');
            syncModalFromState();
        };
    }
    if (closeBtn) closeBtn.onclick = () => modal.classList.add('hidden');
    window.onclick = (e) => { if (e.target === modal) modal.classList.add('hidden'); };

    // --- Per-direction settings listeners ---
    // A→B
    setupSettingCheckbox('timer-enabled-ab', 'timerEnabledAB');
    setupSettingNumber('timer-minutes-ab', 'timerMinutesAB');
    setupSettingCheckbox('obs-enabled-ab', 'obsEnabledAB');
    setupSettingNumber('fade-duration-ab', 'fadeDurationAB', true);
    // B→A
    setupSettingCheckbox('timer-enabled-ba', 'timerEnabledBA');
    setupSettingNumber('timer-minutes-ba', 'timerMinutesBA');
    setupSettingCheckbox('obs-enabled-ba', 'obsEnabledBA');
    setupSettingNumber('fade-duration-ba', 'fadeDurationBA', true);

    // Common
    const hotkeyInput = document.getElementById('hotkey-switch');
    if (hotkeyInput) {
        hotkeyInput.onchange = (e) => {
            const val = e.target.value.toUpperCase();
            state.settings.hotkeySwitch = val;
            saveState(false);
            showToast(`Hotkey: ${val}`);
        };
    }

    // OBS connection settings
    setupSettingText('obs-host', 'obsHost');
    setupSettingNumber('obs-port', 'obsPort');
    setupSettingText('obs-password', 'obsPassword');
    setupSettingText('obs-scene-a', 'obsSceneA');
    setupSettingText('obs-scene-b', 'obsSceneB');

    const obsConnBtn = document.getElementById('btn-obs-connect');
    if (obsConnBtn) {
        obsConnBtn.onclick = () => {
            if (state.ws && state.wsConnected) {
                // Send updated OBS config to backend then connect
                state.ws.send(JSON.stringify({
                    type: 'obs_update_config',
                    host: state.settings.obsHost,
                    port: state.settings.obsPort,
                    password: state.settings.obsPassword
                }));
                state.ws.send(JSON.stringify({ type: 'obs_connect' }));
                showToast('OBS connecting...');
            }
        };
    }

    // Swtich Mode Buttons (AB/BA)
    document.querySelectorAll('.btn-mode-select').forEach(btn => {
        btn.onclick = (e) => {
            const val = btn.dataset.val;
            const group = btn.closest('.button-group-mode');
            const isAB = group.id === 'mode-group-ab';

            if (isAB) state.settings.switchModeAB = val;
            else state.settings.switchModeBA = val;

            saveState(false);
            updateSwitchUI();
        };
    });

    // Shuffle/Order Toggle Buttons
    document.getElementById('btn-mode-a').onclick = () => togglePlayMode('A');
    document.getElementById('btn-mode-b').onclick = () => togglePlayMode('B');

    // Bottom Controls
    document.getElementById('btn-switch-deck').onclick = () => switchDeck();

    // Test Loop
    document.getElementById('btn-test-loop').onclick = () => {
        // Force 'resume' mode during test to prevent skipping the track
        if (state.mode === 'A') switchDeck('resume');
        const p = state.deckB.activePlayer === 1 ? state.deckB.p1 : state.deckB.p2;
        p.seekTo(state.deckB.loopEnd - parseFloat(document.getElementById('test-duration').value));
        p.playVideo();
        state.isTestingLoop = true;
        setTimeout(() => state.isTestingLoop = false, 3000);
    };

    document.getElementById('btn-analyze-loop').onclick = () => {
        let url = document.getElementById('input-b').value;
        if (!url && state.deckB.currentUrl) url = state.deckB.currentUrl;
        if (!url) { showToast("No URL to analyze"); return; }
        if (state.ws && state.wsConnected) {
            showToast("Analyzing Audio...");
            document.getElementById('global-status').textContent = "Analyzing Loop... Please Wait";
            state.ws.send(JSON.stringify({ type: 'analyze_loop', url }));
        } else {
            showToast("WebSocket not connected");
        }
    };

    setupSeekAndVol();
    initCustomDnD();
}

function updateSwitchUI() {
    // AB
    const modeAB = state.settings.switchModeAB;
    const groupAB = document.getElementById('mode-group-ab');
    groupAB.querySelectorAll('.btn-mode-select').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.val === modeAB);
    });

    // BA
    const modeBA = state.settings.switchModeBA;
    const groupBA = document.getElementById('mode-group-ba');
    groupBA.querySelectorAll('.btn-mode-select').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.val === modeBA);
    });
}

function togglePlayMode(deckKey) {
    const key = `playMode${deckKey}`;
    const current = state.settings[key];
    const next = current === 'order' ? 'shuffle' : 'order';
    state.settings[key] = next;

    updatePlayModeUI(deckKey);
    saveState(false);
}

function updatePlayModeUI(deckKey) {
    const btn = document.getElementById(`btn-mode-${deckKey.toLowerCase()}`);
    const mode = state.settings[`playMode${deckKey}`];

    if (mode === 'shuffle') {
        btn.innerHTML = '<i class="fa-solid fa-shuffle"></i>';
        btn.title = "Queue Mode: Shuffle";
        btn.classList.add('mode-shuffle');
    } else {
        btn.innerHTML = '<i class="fa-solid fa-arrow-down-1-9"></i>';
        btn.title = "Queue Mode: Order";
        btn.classList.remove('mode-shuffle');
    }
}

// ============ LIST MANAGEMENT (Queue & Library) ============

function addToLibraryFromDeck(deckKey) {
    // Try input field first, fallback to currentUrl in state
    let url = document.getElementById(deckKey === 'deckA' ? 'input-a' : 'input-b').value;
    if (!url) {
        url = (deckKey === 'deckA') ? state.deckA.currentUrl : state.deckB.currentUrl;
    }

    const title = document.getElementById(deckKey === 'deckA' ? 'info-a-title' : 'info-b-title').textContent;

    if (!url) {
        showToast("No track loaded");
        return;
    }
    if (title === 'No Track') {
        showToast("Load a track first");
        return;
    }

    // Check dup
    const existingIndex = state.library.findIndex(i => i.url === url);
    if (existingIndex !== -1) {
        if (confirm("This track is already in the library. Overwrite with current settings?")) {
            pushHistory();
            state.library[existingIndex] = {
                url, title,
                loopStart: (deckKey === 'deckB' ? parseFloat(document.getElementById('loop-start-b').value) : state.library[existingIndex].loopStart),
                loopEnd: (deckKey === 'deckB' ? parseFloat(document.getElementById('loop-end-b').value) : state.library[existingIndex].loopEnd),
                id: state.library[existingIndex].id // keep same ID
            };
            renderAllLists();
            saveState();
            showToast("Library updated (Overwritten)");
        }
        return;
    }

    const item = {
        url, title,
        loopStart: (deckKey === 'deckB' ? parseFloat(document.getElementById('loop-start-b').value) : null),
        loopEnd: (deckKey === 'deckB' ? parseFloat(document.getElementById('loop-end-b').value) : null),
        id: Date.now().toString()
    };
    pushHistory();
    state.library.push(item);
    renderAllLists();
    saveState();
    showToast("Added to Library");
}

function addFromLibraryToQueue(libId, targetDeck) {
    const libItem = state.library.find(i => i.id === libId);
    if (!libItem) return;

    // Clone item for queue
    const qItem = { ...libItem, id: Date.now().toString() + Math.random().toString().substr(2, 4) };

    pushHistory();
    if (targetDeck === 'deckA') state.deckA.queue.push(qItem);
    else state.deckB.queue.push(qItem);

    renderAllLists();
    saveState();
    showToast(`Queued to ${targetDeck === 'deckA' ? 'A' : 'B'}`);
}

function processClipboardUrl(url) {
    // Determine info (async fetch title mainly)
    const vid = extractVideoId(url);
    const title = "Clip " + vid.substr(0, 5); // Temp title

    const item = { url, title, id: Date.now().toString() };

    const target = state.settings.clipboardTargetDeck || 'library';

    pushHistory();
    if (target === 'library') state.library.push(item);
    else if (target === 'deckA') state.deckA.queue.push(item);
    else if (target === 'deckB') state.deckB.queue.push(item);

    // Fetch real title update
    fetch(`https://noembed.com/embed?url=https://www.youtube.com/watch?v=${vid}`).then(r => r.json()).then(d => {
        if (d.title) {
            item.title = d.title;
            renderAllLists();
            saveState();
        }
    });

    renderAllLists();
    saveState();
    showToast(`Clip added to ${target}`);
}

function removeItem(listType, id) {
    pushHistory();
    if (listType === 'library') {
        state.library = state.library.filter(i => i.id !== id);
    } else if (listType === 'deckA') {
        state.deckA.queue = state.deckA.queue.filter(i => i.id !== id);
    } else if (listType === 'deckB') {
        state.deckB.queue = state.deckB.queue.filter(i => i.id !== id);
    }
    renderAllLists();
    saveState();
}


function handleReorder(srcListType, srcId, targetId, targetListType = null) {
    // If targetListType is not provided, assume same list reorder
    if (!targetListType) targetListType = srcListType;
    if (srcListType === targetListType && srcId === targetId) return;

    // Helper to get array reference
    const getList = (t) => {
        if (t === 'library') return state.library;
        if (t === 'deckA') return state.deckA.queue;
        if (t === 'deckB') return state.deckB.queue;
        return [];
    };

    const srcList = getList(srcListType);
    const targetList = getList(targetListType);

    const srcIndex = srcList.findIndex(i => i.id === srcId);
    if (srcIndex < 0) return;

    // Move item
    pushHistory();
    // Use JSON parse/stringify to clone if moving between lists to avoid ref issues? No, standard obj ref is fine.
    // Actually, splice returns array.
    const [item] = srcList.splice(srcIndex, 1);

    if (targetListType !== srcListType) {
        // If moving to a different list, we might want to clone instead of move?
        // But for D&D usually it's a move. Let's keep it as move.
        // Wait, if dragging from Library to Queue, usually it's a COPY in DJ apps.
        // But let's follow standard behavior for now: Reorder=Move.
        // Users can use "Send to A" buttons for copying.
        // ACTUALLY: The previous UI buttons did "addFromLibraryToQueue" which is copy.
        // Let's make Library -> Queue a COPY, but Queue -> Queue a MOVE.

        if (srcListType === 'library') {
            // Restore item to library (it was spliced out)
            srcList.splice(srcIndex, 0, item);

            // Create a COPY for the target
            const newItem = { ...item, id: Date.now().toString() }; // New ID
            if (targetId === null) {
                targetList.push(newItem);
            } else {
                let targetIndex = targetList.findIndex(i => i.id === targetId);
                if (targetIndex !== -1) targetList.splice(targetIndex, 0, newItem);
                else targetList.push(newItem);
            }
        } else {
            // Normal Move
            if (targetId === null) {
                targetList.push(item);
            } else {
                let targetIndex = targetList.findIndex(i => i.id === targetId);
                if (targetIndex !== -1) targetList.splice(targetIndex, 0, item);
                else targetList.push(item);
            }
        }
    } else {
        // Same list reorder
        if (targetId === null) {
            targetList.push(item);
        } else {
            let targetIndex = targetList.findIndex(i => i.id === targetId);
            // Since we removed item, indices might shift if target was after source
            // But since we use IDs, findIndex should find where the target ID is NOW.
            if (targetIndex !== -1) {
                targetList.splice(targetIndex, 0, item);
            } else {
                targetList.push(item);
            }
        }
    }

    renderAllLists();
    saveState();
}

function renderAllLists() {
    renderList('queue-list-a', state.deckA.queue, 'deckA');
    renderList('queue-list-b', state.deckB.queue, 'deckB');
    renderList('library-list', state.library, 'library');

    // Update Counts
    document.getElementById('count-a').textContent = `${state.deckA.queue.length} items`;
    document.getElementById('count-b').textContent = `${state.deckB.queue.length} items`;
    document.getElementById('count-lib').textContent = `${state.library.length} items`;
}

function renderList(containerId, listData, type) {
    const container = document.getElementById(containerId);
    container.innerHTML = '';

    listData.forEach(item => {
        const el = document.createElement('div');
        el.className = 'queue-item';
        el.dataset.id = item.id;

        // Actions buttons depending on Type
        let actionsHtml = '';
        if (type === 'library') {
            actionsHtml = `
                <div class="q-actions">
                    <button class="btn-mini btn-to-a" title="Queue to A">A</button>
                    <button class="btn-mini btn-to-b" title="Queue to B">B</button>
                    <button class="btn-mini btn-del" title="Delete">×</button>
                </div>
            `;
        } else {
            actionsHtml = `
                <div class="q-actions">
                    <button class="btn-mini btn-del">×</button>
                </div>
            `;
        }

        // Thumbnail
        const videoId = extractVideoId(item.url);
        const thumbHtml = videoId
            ? `<img class="q-thumb" src="https://img.youtube.com/vi/${videoId}/default.jpg" loading="lazy" alt="">`
            : '';

        // Content
        el.innerHTML = `
            ${thumbHtml}
            <div class="q-content">
                <span class="q-title">${item.title}</span>
                <span class="q-time">${item.loopStart ? `Loop: ${formatTime(item.loopStart)}-${formatTime(item.loopEnd)}` : ''}</span>
            </div>
            ${actionsHtml}
        `;

        // D&D Handlers (Custom)
        el.onmousedown = (e) => onDndDown(e, item, type, el);

        el.onclick = (e) => {
            // Prevent click if it was a drag
            if (dndState.isDragging) return;

            if (e.target.tagName !== 'BUTTON' && !titleEl.isContentEditable) {
                if (type === 'library') {
                    // Library item click -> maybe select or do nothing? (Buttons handle actions)
                } else {
                    // Queue item click -> load
                    loadTrackDirect(type, item.url);
                    if (type === 'deckB' && item.loopStart) {
                        state.deckB.loopStart = item.loopStart;
                        state.deckB.loopEnd = item.loopEnd;
                        document.getElementById('loop-start-b').value = item.loopStart;
                        document.getElementById('loop-end-b').value = item.loopEnd;
                    }
                }
            }
        };

        const titleEl = el.querySelector('.q-title');

        // Double Click to Edit
        titleEl.ondblclick = (e) => {
            e.stopPropagation(); // prevent load
            titleEl.contentEditable = true;
            titleEl.focus();
            titleEl.classList.add('editing');
        };

        // Blur (Finish Edit)
        titleEl.onblur = (e) => {
            titleEl.contentEditable = false;
            titleEl.classList.remove('editing');
            if (item.title !== e.target.textContent) {
                item.title = e.target.textContent;
                saveState(false);
            }
        };

        // Enter to Finish
        titleEl.onkeydown = (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                titleEl.blur();
            }
        };

        el.querySelector('.btn-del').onclick = (e) => { e.stopPropagation(); removeItem(type, item.id); };

        if (type === 'library') {
            el.querySelector('.btn-to-a').onclick = (e) => { e.stopPropagation(); addFromLibraryToQueue(item.id, 'deckA'); };
            el.querySelector('.btn-to-b').onclick = (e) => { e.stopPropagation(); addFromLibraryToQueue(item.id, 'deckB'); };
        } else {
            // Queue Item Click -> Load (Single Click) - Handled in onmousedown/onclick above
        }

        container.appendChild(el);
        container.appendChild(el);
    });
} // End renderList

// ============ CUSTOM DND SYSTEM (JS Controlled) ============

/**
 * Initialize custom DnD system.
 * Replaces standard HTML5 DnD to allow wheel scrolling while dragging.
 */
const dndState = {
    isDragging: false,
    dragItem: null,      // The original data item
    dragEl: null,        // The element being dragged (original)
    ghostEl: null,       // The floating visual element
    placeholder: null,   // The visual placeholder in the list
    sourceType: null,    // 'deckA', 'deckB', 'library'
    startX: 0, startY: 0,
    currentX: 0, currentY: 0,
    scrollingContainer: null,
    autoScrollInterval: null,
    mouseDown: false // Add mouseDown flag
};

function initCustomDnD() {
    window.addEventListener('mousemove', onDndMove, { passive: false });
    window.addEventListener('mouseup', onDndUp);
}

function onDndDown(e, item, type, element) {
    if (e.target.tagName === 'BUTTON' || e.target.tagName === 'INPUT') return;
    if (e.button !== 0) return; // Only left click

    dndState.isDragging = false; // Wait for movement to start dragging
    dndState.dragItem = item;
    dndState.sourceType = type;
    dndState.dragEl = element;
    dndState.startX = e.clientX;
    dndState.startY = e.clientY;

    // Potential drag start
    dndState.mouseDown = true;
}

function onDndMove(e) {
    if (!dndState.mouseDown) return;

    // Start dragging if moved more than 5px
    if (!dndState.isDragging) {
        if (Math.abs(e.clientX - dndState.startX) > 5 || Math.abs(e.clientY - dndState.startY) > 5) {
            startDrag(e);
        }
    }

    if (dndState.isDragging) {
        e.preventDefault(); // Prevent text selection etc.
        dndState.currentX = e.clientX;
        dndState.currentY = e.clientY;

        // Move ghost
        if (dndState.ghostEl) {
            dndState.ghostEl.style.transform = `translate(${e.clientX + 10}px, ${e.clientY + 10}px)`;
        }

        // Find drop target
        const targetContainer = getContainerFromPoint(e.clientX, e.clientY);
        handleDragHover(targetContainer, e.clientY);

        // Auto scroll
        handleAutoScroll(targetContainer, e.clientY);
    }
}

function startDrag(e) {
    dndState.isDragging = true;

    // Create ghost element
    dndState.ghostEl = dndState.dragEl.cloneNode(true);
    dndState.ghostEl.classList.add('dnd-ghost');
    dndState.ghostEl.style.width = `${dndState.dragEl.offsetWidth}px`;
    dndState.ghostEl.style.position = 'fixed';
    dndState.ghostEl.style.left = '0';
    dndState.ghostEl.style.top = '0';
    dndState.ghostEl.style.zIndex = '9999';
    dndState.ghostEl.style.pointerEvents = 'none';
    dndState.ghostEl.style.opacity = '0.8';
    dndState.ghostEl.style.transform = `translate(${e.clientX + 10}px, ${e.clientY + 10}px)`;
    document.body.appendChild(dndState.ghostEl);

    // Create placeholder
    dndState.placeholder = document.createElement('div');
    dndState.placeholder.className = 'queue-placeholder';
    dndState.placeholder.style.height = `${dndState.dragEl.offsetHeight}px`;

    dndState.dragEl.classList.add('dragging-source');
    document.body.classList.add('dragging-active');
    if (window.getSelection) {
        window.getSelection().removeAllRanges();
    }
}

function onDndUp(e) {
    dndState.mouseDown = false;

    if (dndState.isDragging) {
        finishDrag();
    }

    // Valid click (not drag) is handled by onclick on the element
}

function finishDrag() {
    // 1. Determine drop target
    let targetType = null;
    let targetId = null; // ID to drop BEFORE

    if (dndState.placeholder && dndState.placeholder.parentNode) {
        const container = dndState.placeholder.parentNode;

        // Identify container type by ID heavily
        if (container.id === 'queue-list-a') targetType = 'deckA';
        else if (container.id === 'queue-list-b') targetType = 'deckB';
        else if (container.id === 'library-list') targetType = 'library';

        // Find reference node (next sibling of placeholder)
        const nextEl = dndState.placeholder.nextElementSibling;
        if (nextEl && nextEl.dataset.id) {
            targetId = nextEl.dataset.id;
        }

        console.log("Finish Drag:", { targetType, targetId, from: dndState.sourceType });
    } else {
        console.log("No placeholder parent found.");
    }

    // 2. Cleanup
    if (dndState.ghostEl) dndState.ghostEl.remove();
    if (dndState.placeholder) dndState.placeholder.remove();
    if (dndState.dragEl) dndState.dragEl.classList.remove('dragging-source');
    document.body.classList.remove('dragging-active');
    clearInterval(dndState.autoScrollInterval);

    dndState.isDragging = false;
    dndState.ghostEl = null;
    dndState.placeholder = null;
    dndState.dragEl = null;

    // 3. Execute Move
    if (targetType) {
        handleReorder(dndState.sourceType, dndState.dragItem.id, targetId, targetType);
    }
}

function getContainerFromPoint(x, y) {
    // Try to find a list container under cursor
    // Since ghost might cover it, we can use elementsFromPoint or hide ghost briefly
    if (dndState.ghostEl) dndState.ghostEl.style.display = 'none';
    const el = document.elementFromPoint(x, y);
    if (dndState.ghostEl) dndState.ghostEl.style.display = '';

    return el ? el.closest('.queue-list, .library-list') : null;
}

function handleDragHover(container, y) {
    if (!container) return;

    // Check if we can start reordering in this container
    // If dragging from Lib to Queue, or Queue to same Queue, or Queue to Lib
    // (Assuming all moves allowed for now)

    if (!dndState.placeholder) return;

    if (!container.contains(dndState.placeholder)) {
        container.appendChild(dndState.placeholder);
    }

    const afterElement = getDragAfterElement(container, y);
    if (afterElement == null) {
        container.appendChild(dndState.placeholder);
    } else {
        container.insertBefore(dndState.placeholder, afterElement);
    }
}

function handleAutoScroll(container, y) {
    clearInterval(dndState.autoScrollInterval);
    if (!container) return;

    const rect = container.getBoundingClientRect();
    const scrollZone = 60;
    const maxSpeed = 20;

    let speed = 0;
    if (y < rect.top + scrollZone) {
        const dist = (rect.top + scrollZone) - y;
        speed = -Math.pow(Math.min(3, dist / scrollZone), 1.5) * maxSpeed;
    } else if (y > rect.bottom - scrollZone) {
        const dist = y - (rect.bottom - scrollZone);
        speed = Math.pow(Math.min(3, dist / scrollZone), 1.5) * maxSpeed;
    }

    if (speed !== 0) {
        dndState.autoScrollInterval = setInterval(() => {
            container.scrollTop += speed;
        }, 16);
    }
}

function handleReorder(fromType, itemId, targetId, targetType = null) {
    if (!targetType) targetType = fromType; // Default to same list

    const sourceList = (fromType === 'library') ? state.library : ((fromType === 'deckA') ? state.deckA.queue : state.deckB.queue);
    const targetList = (targetType === 'library') ? state.library : ((targetType === 'deckA') ? state.deckA.queue : state.deckB.queue);

    // Find Item
    const itemIndex = sourceList.findIndex(i => i.id === itemId);
    if (itemIndex === -1) return;
    const item = sourceList[itemIndex];

    // Remove from source
    sourceList.splice(itemIndex, 1);

    // Insert into target
    if (targetId) {
        const targetIndex = targetList.findIndex(i => i.id === targetId);
        if (targetIndex !== -1) {
            targetList.splice(targetIndex, 0, item);
        } else {
            targetList.push(item);
        }
    } else {
        targetList.push(item);
    }

    saveState(true);
    renderAllLists();
}

function getDragAfterElement(container, y) {
    // Exclude placeholder and dragging source
    const draggableElements = [...container.querySelectorAll('.queue-item:not(.dragging-source):not(.queue-placeholder)')];

    return draggableElements.reduce((closest, child) => {
        const box = child.getBoundingClientRect();
        const offset = y - box.top - box.height / 2;
        if (offset < 0 && offset > closest.offset) {
            return { offset: offset, element: child };
        } else {
            return closest;
        }
    }, { offset: Number.NEGATIVE_INFINITY }).element;
}

function updateSelectors(id, list) {
    const sel = document.getElementById(id);
    sel.innerHTML = list.length ? '' : '<option>(Empty)</option>';
    list.forEach(i => {
        const opt = document.createElement('option');
        opt.value = i.id;
        opt.textContent = i.title;
        sel.appendChild(opt);
    });
}

// ============ PLAYBACK & SWITCH ============

function switchDeck(forceMode = null) {
    const toB = (state.mode === 'A');
    state.mode = toB ? 'B' : 'A';

    const targetDeck = toB ? state.deckB : state.deckA;
    const mode = (typeof forceMode === 'string') ? forceMode : (toB ? state.settings.switchModeAB : state.settings.switchModeBA);

    // Check Directional Triggers
    const timerEnabled = toB ? state.settings.timerEnabledAB : state.settings.timerEnabledBA;
    const obsEnabled = toB ? state.settings.obsEnabledAB : state.settings.obsEnabledBA;
    const fadeDuration = (toB ? state.settings.fadeDurationAB : state.settings.fadeDurationBA) || 2.0;

    // Stop Timer, restart if enabled for this direction
    stopTimer();
    if (timerEnabled) {
        const mins = toB ? (state.settings.timerMinutesAB || 10) : (state.settings.timerMinutesBA || 10);
        startTimer(mins);
    }

    if (mode === 'restart') {
        const p = toB ? (targetDeck.activePlayer === 1 ? targetDeck.p1 : targetDeck.p2) : targetDeck.player;
        p.seekTo(0);
        p.playVideo();
    } else if (mode === 'next') {
        const modeKey = toB ? state.settings.playModeB : state.settings.playModeA;
        if (targetDeck.queue.length > 0) {
            let itemIndex = 0;
            if (modeKey === 'shuffle') {
                itemIndex = Math.floor(Math.random() * targetDeck.queue.length);
            }

            // Get Item (do NOT rotate the queue - keep order unchanged)
            const item = targetDeck.queue[itemIndex];

            loadTrackDirect(toB ? 'deckB' : 'deckA', item.url, true);

            if (toB && item.loopStart) {
                targetDeck.loopStart = item.loopStart;
                targetDeck.loopEnd = item.loopEnd;
                document.getElementById('loop-start-b').value = item.loopStart;
                document.getElementById('loop-end-b').value = item.loopEnd;
            }
        }
    } else {
        const p = toB ? (targetDeck.activePlayer === 1 ? targetDeck.p1 : targetDeck.p2) : targetDeck.player;
        p.playVideo();
    }

    animateCrossfade(toB ? 0 : 100, toB ? 100 : 0, fadeDuration * 1000);

    document.getElementById('deck-a').classList.toggle('active', !toB);
    document.getElementById('deck-b').classList.toggle('active', toB);
    document.getElementById('btn-switch-deck').classList.toggle('battle-mode', toB);
    document.getElementById('btn-switch-deck').innerHTML = toB ? '<span class="btn-text">🔀 TO DECK A</span>' : '<span class="btn-text">🔀 TO DECK B</span>';

    // OBS Switch Trigger (direction-specific)
    if (obsEnabled && state.wsConnected && state.ws) {
        const sceneName = toB ? (state.settings.obsSceneB || 'Deck B') : (state.settings.obsSceneA || 'Deck A');
        state.ws.send(JSON.stringify({ type: 'obs_switch', scene: sceneName }));
    }

    state.pendingHotkeySwitch = false;
}

function loadTrackDirect(deckKey, url, autoPlay = true) {
    const vid = extractVideoId(url);
    if (!vid) return;

    // Update Input UI
    document.getElementById(deckKey === 'deckA' ? 'input-a' : 'input-b').value = url;

    if (deckKey === 'deckA') {
        state.deckA.videoId = vid;
        state.deckA.currentUrl = url;
        if (autoPlay) state.deckA.player.loadVideoById(vid); else state.deckA.player.cueVideoById(vid);
        fetchTitle(vid, 'info-a-title');
    } else {
        state.deckB.videoId = vid;
        state.deckB.currentUrl = url;
        // Reset loop to defaults for new track
        state.deckB.loopStart = 0;
        state.deckB.loopEnd = 9999;
        document.getElementById('loop-start-b').value = '0';
        document.getElementById('loop-end-b').value = '0';
        resetDeckB();
        state.deckB.p1.loadVideoById(vid);
        state.deckB.p2.cueVideoById(vid);
        if (!autoPlay) state.deckB.p1.pauseVideo();
        fetchTitle(vid, 'info-b-title');
    }
}

function animateCrossfade(start, end, duration) {
    const startTime = Date.now();
    function step() {
        const progress = Math.min((Date.now() - startTime) / duration, 1);
        state.crossfade = start + (end - start) * (1 - Math.pow(1 - progress, 3));
        applyMixer();
        if (progress < 1) requestAnimationFrame(step);
        else if (state.mode === 'A') {
            if (state.deckB.p1) state.deckB.p1.pauseVideo();
            if (state.deckB.p2) state.deckB.p2.pauseVideo();
        }
    }
    requestAnimationFrame(step);
}

function applyMixer() {
    const slider = document.getElementById('crossfader');
    if (slider) slider.value = state.crossfade;

    const volA = document.getElementById('vol-a').value * ((100 - state.crossfade) / 100);
    const volB = document.getElementById('vol-b').value * (state.crossfade / 100);

    if (state.deckA.player) state.deckA.player.setVolume(volA);
    if (state.deckB.p1) state.deckB.p1.setVolume(volB);
    if (state.deckB.p2) state.deckB.p2.setVolume(volB);
}

function togglePlay(deckKey) {
    if (deckKey === 'deckA') {
        const p = state.deckA.player;
        if (p.getPlayerState() === YT.PlayerState.PLAYING) p.pauseVideo(); else p.playVideo();
    } else {
        const p = state.deckB.activePlayer === 1 ? state.deckB.p1 : state.deckB.p2;
        if (p.getPlayerState() === YT.PlayerState.PLAYING) p.pauseVideo(); else p.playVideo();
    }
}

function extractVideoId(url) {
    const m = url.match(/(?:youtu\.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/);
    return (m && m[1].length === 11) ? m[1] : null;
}

function fetchTitle(vid, elId) {
    fetch(`https://noembed.com/embed?url=https://www.youtube.com/watch?v=${vid}`).then(r => r.json()).then(d => {
        if (d.title) document.getElementById(elId).textContent = d.title;
    });
}

function resetAll() {
    if (state.mode === 'B') switchDeck();
    if (state.deckA.player) state.deckA.player.stopVideo();
    resetDeckB();
}

function setupSeekAndVol() {
    ['a', 'b'].forEach(k => {
        document.getElementById(`seek-${k}`).oninput = (e) => {
            const p = k === 'a' ? state.deckA.player : (state.deckB.activePlayer === 1 ? state.deckB.p1 : state.deckB.p2);
            p.seekTo(p.getDuration() * (e.target.value / 100));
        };
        document.getElementById(`vol-${k}`).oninput = applyMixer;
    });
    document.getElementById('crossfader').oninput = (e) => {
        state.crossfade = parseInt(e.target.value);
        applyMixer();
    };
}

// Websocket
function connectWebSocket() {
    if (state.ws) {
        state.ws.onopen = null;
        state.ws.onmessage = null;
        state.ws.onclose = null;
        state.ws.onerror = null;
        state.ws.close();
    }

    state.ws = new WebSocket(`ws://${location.host}/ws`);
    state.ws.onopen = () => {
        state.wsConnected = true;
        document.getElementById('ws-status-dot').className = 'status-dot connected';
        document.getElementById('ws-status-text').textContent = 'Connected';
        state.ws.send(JSON.stringify({ type: 'get_state' }));
        console.log("WebSocket Connected");
    };
    state.ws.onmessage = (e) => {
        const msg = JSON.parse(e.data);
        if (msg.type === 'state') {
            if (msg.playlists) {
                state.deckA.queue = msg.playlists.deckA || [];
                state.deckB.queue = msg.playlists.deckB || [];
                state.library = msg.playlists.library || [];
                renderAllLists();
            }
            if (msg.settings) {
                Object.assign(state.settings, msg.settings);
                // Update UI from settings
                updatePlayModeUI('A');
                updatePlayModeUI('B');
                updateSwitchUI();
                if (document.querySelector(`#clipboard-target option[value="${state.settings.clipboardTargetDeck}"]`)) {
                    document.getElementById('clipboard-target').value = state.settings.clipboardTargetDeck;
                }
                document.getElementById('clipboard-watch').checked = state.settings.clipboardWatchEnabled || false;
                state.clipboardWatchEnabled = state.settings.clipboardWatchEnabled || false;
            }
        } else if (msg.type === 'hotkey_triggered') {
            console.log("Global Hotkey Triggered:", msg.action);
            if (document.hidden) {
                state.pendingHotkeySwitch = true;
            } else {
                switchDeck();
            }
        } else if (msg.type === 'clipboard_url') {
            processClipboardUrl(msg.url);
        } else if (msg.type === 'loop_analyzed') {
            if (msg.success) {
                document.getElementById('loop-start-b').value = msg.loopStart.toFixed(2);
                document.getElementById('loop-end-b').value = msg.loopEnd.toFixed(2);
                state.deckB.loopStart = msg.loopStart;
                state.deckB.loopEnd = msg.loopEnd;
                showToast(`Loop Found! (Conf: ${msg.confidence.toFixed(3)})`);
                document.getElementById('global-status').textContent = `SYSTEM READY | Loop found: ${msg.loopStart.toFixed(1)}s-${msg.loopEnd.toFixed(1)}s`;
            } else {
                showToast(`Analysis failed: ${msg.error}`);
                document.getElementById('global-status').textContent = "SYSTEM READY";
            }
        } else if (msg.type === 'obs_connected') {
            const statusEl = document.getElementById('obs-status');
            if (statusEl) {
                if (msg.success) {
                    statusEl.textContent = 'Connected';
                    statusEl.className = 'status-badge status-connected';
                    showToast('OBS Connected!');
                } else {
                    statusEl.textContent = 'Disconnected';
                    statusEl.className = 'status-badge status-disconnected';
                    showToast('OBS Connection Failed');
                }
            }
        } else if (msg.type === 'obs_scene_changed') {
            // OBS -> App Trigger
            // If current deck is A, and scene changes to Scene B, switch to B (if enabled)
            // If current deck is B, and scene changes to Scene A, switch to A (if enabled)

            const currentDeck = state.mode; // 'A' or 'B'
            const newScene = msg.scene;
            const sceneA = state.settings.obsSceneA || 'Deck A';
            const sceneB = state.settings.obsSceneB || 'Deck B';

            // If currently A, check if we should switch to B
            if (currentDeck === 'A') {
                // Check if B's trigger is enabled (meaning "Switch TO B" trigger)
                // Actually, the setting is "obsEnabledAB" which means "When switching A->B, trigger OBS"
                // But for bi-directional, we use the same flag: "Link Deck B with Scene B"
                if (state.settings.obsEnabledAB && newScene === sceneB) {
                    console.log(`OBS Scene matched Deck B (${newScene}). Switching to B...`);
                    switchDeck();
                }
            }
            // If currently B, check if we should switch to A
            else if (currentDeck === 'B') {
                if (state.settings.obsEnabledBA && newScene === sceneA) {
                    console.log(`OBS Scene matched Deck A (${newScene}). Switching to A...`);
                    switchDeck();
                }
            }
        }
    };
    state.ws.onclose = () => {
        state.wsConnected = false;
        document.getElementById('ws-status-dot').className = 'status-dot disconnected';
        document.getElementById('ws-status-text').textContent = 'Disconnected (Reconnecting...)';
        console.log("WebSocket Disconnected. Retrying in 5s...");
        setTimeout(connectWebSocket, 5000);
    };
    state.ws.onerror = (err) => {
        console.error("WebSocket Error:", err);
        state.ws.close();
    };
}

function saveState(hist = true) {
    if (state.ws) state.ws.send(JSON.stringify({
        type: 'save_state',
        playlists: {
            deckA: state.deckA.queue,
            deckB: state.deckB.queue,
            library: state.library
        },
        settings: state.settings
    }));
}

function showToast(msg) {
    const el = document.getElementById('global-status');
    el.textContent = msg;
    setTimeout(() => el.textContent = 'SYSTEM READY', 3000);
}

// Timer
function startTimer(minutes) {
    clearInterval(state.timerInterval);
    state.timerStartTime = Date.now();
    const durationMs = (minutes || 10) * 60000;
    state.timerInterval = setInterval(() => {
        const rem = durationMs - (Date.now() - state.timerStartTime);
        if (rem <= 0) {
            stopTimer();
            document.getElementById('match-timer').textContent = '00:00';
            switchDeck();
            return;
        }
        document.getElementById('match-timer').textContent = formatTime(rem / 1000);
    }, 1000);
    document.getElementById('match-timer').textContent = formatTime(durationMs / 1000);
}
function stopTimer() {
    clearInterval(state.timerInterval);
    document.getElementById('match-timer').textContent = '--:--';
}

// YT Init
window.onYouTubeIframeAPIReady = function () {
    state.deckA.player = new YT.Player('player-a', {
        height: '1', width: '1', playerVars: { playsinline: 1, controls: 0, disablekb: 1 },
        events: { onReady: () => { state.deckA.ready = true; } }
    });
    state.deckB.p1 = new YT.Player('player-b-1', {
        height: '1', width: '1', playerVars: { playsinline: 1, controls: 0, disablekb: 1 },
        events: { onReady: () => { state.deckB.ready1 = true; } }
    });
    state.deckB.p2 = new YT.Player('player-b-2', {
        height: '1', width: '1', playerVars: { playsinline: 1, controls: 0, disablekb: 1 },
        events: { onReady: () => { state.deckB.ready2 = true; } }
    });
};

// ============ SETTINGS HELPERS ============

function syncModalFromState() {
    const s = state.settings;
    // A→B
    const timerAB = document.getElementById('timer-enabled-ab');
    if (timerAB) timerAB.checked = s.timerEnabledAB || false;
    const timerMinAB = document.getElementById('timer-minutes-ab');
    if (timerMinAB) timerMinAB.value = s.timerMinutesAB || 10;
    const obsAB = document.getElementById('obs-enabled-ab');
    if (obsAB) obsAB.checked = s.obsEnabledAB || false;
    const fadeAB = document.getElementById('fade-duration-ab');
    if (fadeAB) fadeAB.value = s.fadeDurationAB || 2.0;
    // B→A
    const timerBA = document.getElementById('timer-enabled-ba');
    if (timerBA) timerBA.checked = s.timerEnabledBA || false;
    const timerMinBA = document.getElementById('timer-minutes-ba');
    if (timerMinBA) timerMinBA.value = s.timerMinutesBA || 10;
    const obsBA = document.getElementById('obs-enabled-ba');
    if (obsBA) obsBA.checked = s.obsEnabledBA || false;
    const fadeBA = document.getElementById('fade-duration-ba');
    if (fadeBA) fadeBA.value = s.fadeDurationBA || 2.0;
    // Common
    const hotkey = document.getElementById('hotkey-switch');
    if (hotkey) hotkey.value = s.hotkeySwitch || 'F8';
    // OBS
    const obsHost = document.getElementById('obs-host');
    if (obsHost) obsHost.value = s.obsHost || 'localhost';
    const obsPort = document.getElementById('obs-port');
    if (obsPort) obsPort.value = s.obsPort || 4455;
    const obsPw = document.getElementById('obs-password');
    if (obsPw) obsPw.value = s.obsPassword || '';
    const scA = document.getElementById('obs-scene-a');
    if (scA) scA.value = s.obsSceneA || 'Deck A';
    const scB = document.getElementById('obs-scene-b');
    if (scB) scB.value = s.obsSceneB || 'Deck B';
}

function setupSettingCheckbox(elementId, settingsKey) {
    const el = document.getElementById(elementId);
    if (el) {
        el.onchange = (e) => {
            state.settings[settingsKey] = e.target.checked;
            saveState(false);
        };
    }
}

function setupSettingNumber(elementId, settingsKey, isFloat = false) {
    const el = document.getElementById(elementId);
    if (el) {
        el.onchange = (e) => {
            state.settings[settingsKey] = isFloat ? parseFloat(e.target.value) : parseInt(e.target.value);
            saveState(false);
        };
    }
}

function setupSettingText(elementId, settingsKey) {
    const el = document.getElementById(elementId);
    if (el) {
        el.onchange = (e) => {
            state.settings[settingsKey] = e.target.value;
            saveState(false);
        };
    }
}

// ============ PAGE VISIBILITY (F8 delay mitigation) ============
document.addEventListener('visibilitychange', () => {
    if (!document.hidden && state.pendingHotkeySwitch) {
        console.log('Executing pending hotkey switch on tab focus');
        switchDeck();
    }
});
